package server

import (
	"fmt"
	"strconv"

	"github.com/labstack/echo/v4"
)

type Options struct {
	Port     int64
	Address  string
	CertFile string // path to the x509 certificate for https
	KeyFile  string // path to the x509 private key matching `CertFile`
}

type EchoServer struct {
	Address  string
	Port     int64
	CertFile string // path to the x509 certificate for https
	KeyFile  string // path to the x509 private key matching `CertFile`
	Echo     *echo.Echo
}

func New(opts *Options) *EchoServer {
	return &EchoServer{
		Address:  opts.Address,
		Port:     opts.Port,
		CertFile: opts.CertFile,
		KeyFile:  opts.KeyFile,
	}
}

func (s *EchoServer) Startup() {
	s.Echo.Logger.Fatal(s.Echo.StartTLS(fmt.Sprintf(":%s", strconv.FormatInt(s.Port, 10)), s.CertFile, s.KeyFile))
}

func (s *EchoServer) Shutdown() {}
