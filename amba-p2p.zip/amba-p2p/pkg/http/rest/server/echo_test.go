package server

//protoc -I=$SRC_DIR --go_out=plugins=grpc:$DST_DIR $SRC_DIR/machine/message.proto
