package client

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"io/ioutil"
	"net/http"
	"net/url"
	"time"
)

type Client struct {
	baseUrl                                 string
	httpClient                              *http.Client
	maxAddressNumPerRequest, maxConcurrency int
}

func NewClient(baseUrl string, timeoutInSecond int) *Client {
	return &Client{
		baseUrl: baseUrl,
		httpClient: &http.Client{
			Timeout: time.Duration(timeoutInSecond) * time.Second,
		},
	}
}

func (c *Client) ExecuteRequest(
	ctx context.Context,
	Method string,
	reqBody string,
	path string,
	dataHolder interface{},
	urlValues map[string]string,
) error {
	req, err := NewRequest(Method, fmt.Sprintf("%s%s", c.baseUrl, path), reqBody, map[string]string{"Accept": "application/json"})
	if err != nil {
		return fmt.Errorf("web.NewRequest: %w", err)
	}

	q := url.Values{}
	for k, v := range urlValues {
		q.Add(k, v)
	}
	req.URL.RawQuery = q.Encode()

	if _, err := Do(c.httpClient, req.WithContext(ctx), dataHolder); err != nil {
		return fmt.Errorf("web.Do: %w", err)
	}

	return nil
}

func NewRequest(method, url string, body interface{}, headers map[string]string) (*http.Request, error) {
	var buf bytes.Buffer
	if body != nil {
		switch v := body.(type) {
		case string:
			if _, err := buf.WriteString(v); err != nil {
				return nil, fmt.Errorf("buf.WriteString: %w", err)
			}
		default:
			if err := json.NewEncoder(&buf).Encode(v); err != nil {
				return nil, fmt.Errorf("json.Encode: %w", err)
			}
		}
	}

	// Create HTTP request
	req, err := http.NewRequest(method, url, &buf)
	if err != nil {
		return nil, fmt.Errorf("http.NewRequest: %w", err)
	}

	if len(headers) != 0 {
		for k, v := range headers {
			req.Header.Add(k, v)
		}
	}

	return req, nil
}

type doer interface {
	Do(*http.Request) (*http.Response, error)
}

// Do makes a request
// the response will be parsed to responseHolder if it is provided
// otherwise the response will be returned
func Do(client doer, req *http.Request, responseHolder interface{}) (*http.Response, error) {
	resp, err := client.Do(req)
	if err != nil {
		return nil, fmt.Errorf("Do:rest.Do: %w", err)
	}
	defer func() {
		_ = resp.Body.Close()
	}()

	if err := extractError(resp); err != nil {
		return nil, fmt.Errorf("Do:extractError: %w", err)
	}

	if responseHolder != nil {
		body, err := io.ReadAll(resp.Body)
		if err != nil {
			return nil, fmt.Errorf("Do:ioutil.ReadAll: %w", err)
		}

		if err := json.Unmarshal(body, responseHolder); err != nil {
			return nil, fmt.Errorf("Do:json.Unmarshal: %w", err)
		}
	}

	return resp, nil
}

// extractError checks if the response signifies an error
// If so, it returns the error.
// Otherwise, it returns nil.
func extractError(resp *http.Response) error {
	if resp.StatusCode == http.StatusOK {
		return nil
	}

	errorBuf, _ := ioutil.ReadAll(resp.Body)
	return NewRequestError(fmt.Errorf("%s", errorBuf), resp.StatusCode)
}

// Error is used to pass an error during the request through the
// application with web specific context.
type Error struct {
	Err    error
	Status int
}

// NewRequestError wraps a provided error with an HTTP status code. This
// function should be used when controller encounter expected errors.
func NewRequestError(err error, status int) error {
	return &Error{err, status}
}

// Error implements the error interface. It uses the default message of the
// wrapped error. This is what will be shown in the services' logs.
func (err *Error) Error() string {
	return err.Err.Error()
}
