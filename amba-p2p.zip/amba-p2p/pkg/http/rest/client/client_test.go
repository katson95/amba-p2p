package client

import (
	"context"
	"fmt"
)

type IProductService interface {
	CountProducts() (int, error)
}

type ProductClient struct {
	Client
}

func (p *ProductClient) CountProducts() (int, error) {
	if err := p.fetch(context.Background(), string("reqBody"), "/api/v1/validator_balance", nil, nil); err != nil {
		return 0, fmt.Errorf("ServiceClient:m.fetch: %w", err)
	}
	return 0, nil
}
