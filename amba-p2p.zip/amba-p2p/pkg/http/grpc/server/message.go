package server

import (
	"context"
	"log"

	"github.com/amba-p2p/pkg/http/grpc/proto/message"
)

type MessageServer struct{}

func (m *MessageServer) SayHello(ctx context.Context, msg *message.Message) (*message.Message, error) {
	log.Printf("Receive message body from client: %s", msg.Body)
	return &message.Message{
		Body: "Hello from server",
	}, nil
}
