package k8s

import (
	"fmt"
	"testing"
)

func TestK3s(t *testing.T) {
	k3sRunner := New("123.0.0.9", "")
	token, err := k3sRunner.RunMaster()
	if err != nil {
		return
	}

	fmt.Println(token)
}
