package tidb

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"

	log "github.com/sirupsen/logrus"
)

type Runner struct{}

func New() *Runner {
	runner := Runner{}
	return &runner
}

func (r *Runner) RunTiDBServer() error {
	curlCmd := exec.Command("curl", "\"=https\"", "--proto", "--tlsv1.2", "-sSf", "https://tiup-mirrors.pingcap.com/install.sh")
	sudoCmd := exec.Command("sh")
	sudoCmd.Env = os.Environ()

	reader, writer := io.Pipe()
	var buffer bytes.Buffer

	curlCmd.Stdout = writer
	sudoCmd.Stdin = reader

	sudoCmd.Stdout = &buffer

	err := curlCmd.Start()
	if err != nil {
		log.Error("curlCmd.Start", err)
		return err
	}

	err = sudoCmd.Start()
	if err != nil {
		log.Error("sudoCmd.Start", err)
		return err
	}

	err = curlCmd.Wait()
	if err != nil {
		log.Error("curlCmd.Wait", err)
		return err
	}

	err = writer.Close()
	if err != nil {
		log.Error("writer.Close", err)
		return err
	}

	err = sudoCmd.Wait()
	if err != nil {
		log.Error("sudoCmd.Wait", err)
		return err
	}

	err = reader.Close()
	if err != nil {
		log.Error("reader.Close", err)
		return err
	}

	/*	sourceCmd := exec.Command("source", "$HOME/.zsh")
		output, err := sourceCmd.Output()
		if err != nil {
			log.Fatal(err)
		}
		fmt.Println(output)*/
	return nil
}

func (r *Runner) RunWhich() error {

	whichCmd := exec.Command("which", "tiup")
	output, err := whichCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}

func (r *Runner) RunVersion() error {

	whichCmd := exec.Command("tiup", "--version")
	output, err := whichCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}

func (r *Runner) InstallClusterComponent() error {

	installClusterCmd := exec.Command("tiup", "cluster")
	installOutput, err := installClusterCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(installOutput))
	return nil
}

func (r *Runner) UpdateClusterComponent() error {

	selfUpdateClusterCmd := exec.Command("tiup", "update", "--self")
	selfUpdateOutput, err := selfUpdateClusterCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(selfUpdateOutput))
	return nil
}

func (r *Runner) UpdateCluster() error {

	updateClusterCmd := exec.Command("tiup", "update", "cluster")
	updateOutput, err := updateClusterCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(updateOutput))
	return nil
}
