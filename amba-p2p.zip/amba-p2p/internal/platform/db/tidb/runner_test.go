package tidb

import (
	"fmt"
	"testing"
)

func TestTiDB(t *testing.T) {
	tiDBRunner := New()
	err := tiDBRunner.RunTiDBServer()
	if err != nil {
		return
	}

	fmt.Println("--------------------")
	err = tiDBRunner.RunWhich()
	if err != nil {
		return
	}
	fmt.Println("--------------------")
	err = tiDBRunner.RunVersion()
	if err != nil {
		return
	}
	fmt.Println("--------------------")
	err = tiDBRunner.InstallClusterComponent()
	if err != nil {
		return
	}
	fmt.Println("--------------------")
	err = tiDBRunner.UpdateClusterComponent()
	if err != nil {
		return
	}

	err = tiDBRunner.UpdateCluster()
	if err != nil {
		return
	}
}
