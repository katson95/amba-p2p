package cassandra

import (
	"testing"
)

func TestCassandraDockerDB(t *testing.T) {
	cassandraContainer := New()

	err := cassandraContainer.GetKeys()
	if err != nil {
		return
	}

	err = cassandraContainer.CreateNetwork()
	if err != nil {
		return
	}

	err = cassandraContainer.RunContainer()
	if err != nil {
		return
	}
	/*
		err := cassandraContainer.CleanUp()
		if err != nil {
			return
		}
	*/
}
