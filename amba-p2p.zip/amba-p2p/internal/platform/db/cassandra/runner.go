package cassandra

import (
	"bytes"
	"fmt"
	"io"
	"os"
	"os/exec"
	"strconv"
	"time"
)

type Runner struct{}

func New() *Runner {
	runner := Runner{}
	return &runner
}

func (r *Runner) Update() (*string, error) {
	fmt.Println("-----------------------------")
	fmt.Println("Updating System..............")

	updateCmd := exec.Command("sudo", "apt", "update")
	outPut, err := updateCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("updateCmd.Output(): %w", err)
	}
	out := string(outPut)
	return &out, nil
}

func (r *Runner) PreReqJDK() (*string, error) {
	fmt.Println("-----------------------------")
	fmt.Println("Installing jdk...............")

	javaCmd := exec.Command("sudo", "apt", "install", "openjdk-8-jdk", "-y")
	outPut, err := javaCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("javaCmd.Output(): %w", err)
	}
	out := string(outPut)
	return &out, nil
}

func (r *Runner) AddRepository() (*string, error) {
	fmt.Println("-----------------------------")
	fmt.Println("Adding Repo..................")

	repoCmd := exec.Command("echo", "deb http://www.apache.org/dist/cassandra/debian 40x main")
	sudoCmd := exec.Command("sudo", "tee", "-a", "/etc/apt/sources.list.d/cassandra.sources.list")

	reader, writer := io.Pipe()
	var buffer bytes.Buffer

	repoCmd.Stdout = writer
	sudoCmd.Stdin = reader

	sudoCmd.Stdout = &buffer

	err := repoCmd.Start()
	if err != nil {
		return nil, fmt.Errorf("repoCmd.Start(): %w", err)
	}

	err = sudoCmd.Start()
	if err != nil {
		return nil, fmt.Errorf("sudoCmd.Start(): %w", err)
	}

	err = repoCmd.Wait()
	if err != nil {
		return nil, fmt.Errorf("repoCmd.Wait(): %w", err)
	}

	err = writer.Close()
	if err != nil {
		return nil, fmt.Errorf("writer.Close(): %w", err)
	}

	err = sudoCmd.Wait()
	if err != nil {
		return nil, fmt.Errorf("sudoCmd.Wait(): %w", err)
	}

	err = reader.Close()
	if err != nil {
		return nil, fmt.Errorf("reader.Close(): %w", err)
	}

	outPut, err := io.Copy(os.Stdout, &buffer)
	if err != nil {
		return nil, fmt.Errorf("io.Copy(): %w", err)
	}
	out := strconv.FormatInt(outPut, 10)
	return &out, nil
}

func (r *Runner) AddKey() (*string, error) {

	fmt.Println("--------------------------------")
	fmt.Println("Adding Key......................")

	wgetCmd := exec.Command("wget", "-q", "-O", "-", "https://www.apache.org/dist/cassandra/KEYS")
	sudoCmd := exec.Command("sudo", "apt-key", "add", "-")

	reader, writer := io.Pipe()
	var buffer bytes.Buffer

	wgetCmd.Stdout = writer
	sudoCmd.Stdin = reader

	sudoCmd.Stdout = &buffer

	err := wgetCmd.Start()
	if err != nil {
		return nil, fmt.Errorf("wgetCmd.Start(): %w", err)
	}

	err = sudoCmd.Start()
	if err != nil {
		return nil, fmt.Errorf("sudoCmd.Start(): %w", err)
	}

	err = wgetCmd.Wait()
	if err != nil {
		return nil, fmt.Errorf("wgetCmd.Wait(): %w", err)
	}

	err = writer.Close()
	if err != nil {
		return nil, fmt.Errorf("writer.Close(): %w", err)
	}

	err = sudoCmd.Wait()
	if err != nil {
		return nil, fmt.Errorf("sudoCmd.Wait(): %w", err)
	}

	err = reader.Close()
	if err != nil {
		return nil, fmt.Errorf("sudoCmd.Wait(): %w", err)
	}

	outPut, err := io.Copy(os.Stdout, &buffer)
	if err != nil {
		return nil, fmt.Errorf("io.Copy: %w", err)
	}
	out := strconv.FormatInt(outPut, 10)
	return &out, nil
}

func (r *Runner) Install() (*string, error) {
	fmt.Println("-----------------------------")
	fmt.Println("Installing Cassandra.........")

	installCmd := exec.Command("sudo", "apt", "install", "cassandra")
	outPut, err := installCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("installCmd.Output(): %w", err)
	}
	out := string(outPut)
	return &out, nil
}

func (r *Runner) Start() (*string, error) {
	fmt.Println("--------------------------------")
	fmt.Println("Starting Cassandra .............")

	svcCmd := exec.Command("sudo", "service", "cassandra", "start")
	outPut, err := svcCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("svcCmd.Output(): %w", err)
	}

	time.Sleep(time.Second * 50)

	out := string(outPut)
	return &out, nil
}

func (r *Runner) Status() (*string, error) {
	fmt.Println("--------------------------------")
	fmt.Println("Waiting for Cassandra to start..")

	attempts := 10
	var outPut []byte
	var err error

	for i := 1; i <= attempts; i++ {
		toolCmd := exec.Command("sudo", "nodetool", "status")
		outPut, err = toolCmd.Output()
		if err != nil {
			switch {
			case i < attempts:
				time.Sleep(2 * time.Second)
				i++
			default:
				return nil, fmt.Errorf("toolCmd.Output(): %w", err)
			}
		}

		if outPut != nil {
			break
		}
	}
	out := string(outPut)
	return &out, nil
}

func (r *Runner) Stop() (*string, error) {
	fmt.Println("--------------------------------")
	fmt.Println("Stopping Cassandra .............")

	svcCmd := exec.Command("sudo", "service", "cassandra", "stop")
	outPut, err := svcCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("svcCmd.Output(): %w", err)
	}

	time.Sleep(time.Second * 10)

	out := string(outPut)
	return &out, nil
}

func (r *Runner) Clean() (*string, error) {
	fmt.Println("--------------------------------")
	fmt.Println("Cleaning data directory.........")

	rmDataCmd := exec.Command("sudo", "rm", "-rf", "/var/lib/cassandra/data/")
	outPut, err := rmDataCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("svcCmd.Output(): %w", err)
	}
	out := string(outPut)

	rmCmtLogCmd := exec.Command("sudo", "rm", "-rf", "/var/lib/cassandra/commitlog/")
	outPut, err = rmCmtLogCmd.Output()
	if err != nil {
		return nil, fmt.Errorf("svcCmd.Output(): %w", err)
	}
	out = fmt.Sprintf("Data: %s Commit Log: %s", out, string(outPut))
	return &out, nil
}
