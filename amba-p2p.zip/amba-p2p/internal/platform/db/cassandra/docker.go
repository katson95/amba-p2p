package cassandra

import (
	"fmt"
	"os/exec"

	log "github.com/sirupsen/logrus"
)

type DockerRunner struct{}

func NewDocker() *Runner {
	runner := Runner{}
	return &runner
}

func (r *DockerRunner) PullImage() error {

	dockerCmd := exec.Command(
		"docker", "pull", "cassandra:latest")
	output, err := dockerCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}

func (r *DockerRunner) CreateNetwork() error {

	dockerCmd := exec.Command(
		"docker", "network", "create", "cassandra")
	output, err := dockerCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}

func (r *DockerRunner) RunContainer() error {

	dockerCmd := exec.Command(
		"docker", "run", "--rm", "-d", "--name", "cassandra", "--hostname", "cassandra", "--network", "cassandra", "cassandra:latest")
	output, err := dockerCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}

func (r *DockerRunner) CleanUp() error {

	killCmd := exec.Command(
		"docker", "kill", "cassandra")
	killOutpu, err := killCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(killOutpu))

	dockerCmd := exec.Command(
		"docker", "network", "rm", "cassandra")
	output, err := dockerCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}
