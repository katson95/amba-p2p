package surreal

import (
	"testing"
)

func TestSurrealDB(t *testing.T) {
	surrealContainer := New()
	err := surrealContainer.RunContainer()
	if err != nil {
		return
	}
}
