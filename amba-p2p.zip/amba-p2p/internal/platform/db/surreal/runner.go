package surreal

import (
	"fmt"
	"os/exec"

	log "github.com/sirupsen/logrus"
)

type Runner struct{}

func New() *Runner {
	runner := Runner{}
	return &runner
}

func (r *Runner) RunContainer() error {

	dockerCmd := exec.Command("docker", "run", "--rm", "--pull", "always", "-d", "-p", "8000:8000", "surrealdb/surrealdb:latest", "start")
	output, err := dockerCmd.Output()
	if err != nil {
		log.Fatal(err)
		return err
	}
	fmt.Println(string(output))
	return nil
}
